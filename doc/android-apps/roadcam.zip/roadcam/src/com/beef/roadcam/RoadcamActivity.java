package com.beef.roadcam;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.hardware.Camera;
import android.hardware.Camera.AutoFocusCallback;
import android.hardware.Camera.PictureCallback;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.media.ExifInterface;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnKeyListener;
import android.view.View.OnTouchListener;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.dropbox.client2.DropboxAPI;
import com.dropbox.client2.android.AndroidAuthSession;
import com.dropbox.client2.session.AccessTokenPair;
import com.dropbox.client2.session.AppKeyPair;
import com.dropbox.client2.session.Session.AccessType;

public class RoadcamActivity extends Activity implements SensorEventListener {
	Button _start, capture, exit_main, exit_cam, upload, delete, logout;
	Spinner saveLocation;
	RoadcamActivity self = this;
	String TAG = "RoadcamActivity Error";
	CameraPreview camSurface;
	Camera mCam;
	Camera.Parameters mParams;
	ExifInterface mExif;
	MyLocation my_location;
	Context context;
	String latitude, longitude, latD, longD, elatitude, elongitude;
	Boolean tagged, timerRunning;
	int currentTime;
	Handler timerUpdateHandler;
	int SECONDS_BETWEEN_PHOTOS = 2;
	SensorManager sensorManager;
	TextView textView;
	LocationManager locationManager;
	Location gpsLocation;
	Location netLocation;
	Boolean firstLogin = true;
	Boolean warned = false;
	static String tempDir;
	float accelx[] = new float[2];
	float accely[] = new float[2];
	float accelz[] = new float[2];
	float orientation[] = new float [3];
	static String imageFolder = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).getPath()+"/MyCameraApp/";
	String saveLocations[];

    final static private String ACCOUNT_PREFS_NAME = "prefs";
    final static private String ACCESS_KEY_NAME = "ACCESS_KEY";
    final static private String ACCESS_SECRET_NAME = "ACCESS_SECRET";
	final static private String APP_KEY = "oamt3xbd2mfsqt3";
	final static private String APP_SECRET = "sacunwrcxma33jr";
	final static private AccessType ACCESS_TYPE = AccessType.APP_FOLDER;
	private DropboxAPI<AndroidAuthSession> mDBApi;
	AppKeyPair appKeys;
	AndroidAuthSession session;
	AccessTokenPair tokens;
	/** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setContentView(R.layout.main);
        camSurface = new CameraPreview(self);
        _start = (Button) findViewById(R.id.start);
        _start.setOnClickListener(start_handler);
        exit_main = (Button) findViewById(R.id.exit);
        exit_main.setOnClickListener(main_exit_handler);
        upload = (Button) findViewById(R.id.upload);
        upload.setOnClickListener(upload_handler);
        delete = (Button) findViewById(R.id.delete);
        delete.setOnClickListener(delete_handler);
        logout = (Button) findViewById(R.id.logout);
        logout.setOnClickListener(logout_handler);
        
        SharedPreferences prefs = getSharedPreferences(ACCOUNT_PREFS_NAME, 0);
        if (prefs.getString("storeDir", "0") == "External SD Card") {
        	saveLocations = new String[] {"External SD Card", "Default"};
        	imageFolder = "/mnt/sdcard/external_sd/MyCameraApp/";
        }
        else {
        	saveLocations = new String[] {"Default", "External SD Card"};
            imageFolder = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).getPath()+"/MyCameraApp/";
        }
        saveLocation = (Spinner) findViewById(R.id.saveSelect);
        ArrayAdapter locationAdapter = new ArrayAdapter(this, android.R.layout.simple_spinner_item, saveLocations);
        locationAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
     	saveLocation.setAdapter(locationAdapter);
		saveLocation.setOnItemSelectedListener(saveSelect);
		
		context = this;
        tagged = false;
        timerRunning = false;
        currentTime = 0;
        timerUpdateHandler = new Handler();
        locationManager = (LocationManager) this.getSystemService(Context.LOCATION_SERVICE);
        locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0, 0, locationListenerNET);
        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, locationListenerGPS);
        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
		sensorManager.registerListener(this,
				sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER),
				SensorManager.SENSOR_DELAY_NORMAL);
		sensorManager.registerListener(this,
				sensorManager.getDefaultSensor(Sensor.TYPE_ORIENTATION),
				sensorManager.SENSOR_DELAY_NORMAL);
		appKeys = new AppKeyPair(APP_KEY, APP_SECRET);
		session = buildSession();
		mDBApi = new DropboxAPI<AndroidAuthSession>(session);
		if (firstLogin) {
			mDBApi.getSession().startAuthentication(RoadcamActivity.this);
			firstLogin = false;
		}
    }   
    
    public void db_upload(String path) {
    	// Uploading content.
    	File file = new File(path);
    	UploadPicture upload = new UploadPicture(this, mDBApi, "", file);
    	upload.execute();
    	/*
    	for (int i = 0; i < fileList.length; i++) {
    		if (fileList[i].isFile()) {
    			upload = new UploadPicture(this, mDBApi, "", fileList[i]);
    			upload.execute();
    		}
    	}
    	*/
    }
    
    void DeleteRecursive(File fileOrDirectory) {
        if (fileOrDirectory.isDirectory())
            for (File child : fileOrDirectory.listFiles())
                DeleteRecursive(child);

        fileOrDirectory.delete();
    }
    
    private String[] getKeys() {
        SharedPreferences prefs = getSharedPreferences(ACCOUNT_PREFS_NAME, 0);
        String key = prefs.getString(ACCESS_KEY_NAME, null);
        String secret = prefs.getString(ACCESS_SECRET_NAME, null);
        if (key != null && secret != null) {
        	String[] ret = new String[2];
        	ret[0] = key;
        	ret[1] = secret;
        	return ret;
        } else {
        	return null;
        }
    }

    /**
     * Shows keeping the access keys returned from Trusted Authenticator in a local
     * store, rather than storing user name & password, and re-authenticating each
     * time (which is not to be done, ever).
     */
    private void storeKeys(String key, String secret) {
        // Save the access key for later
        SharedPreferences prefs = getSharedPreferences(ACCOUNT_PREFS_NAME, 0);
        Editor edit = prefs.edit();
        edit.putString(ACCESS_KEY_NAME, key);
        edit.putString(ACCESS_SECRET_NAME, secret);
        edit.commit();
    }

    private void clearKeys() {
        SharedPreferences prefs = getSharedPreferences(ACCOUNT_PREFS_NAME, 0);
        Editor edit = prefs.edit();
        edit.clear();
        edit.commit();
    }
    
    OnItemSelectedListener saveSelect = new OnItemSelectedListener() {
    	@Override
        public void onItemSelected(AdapterView<?> arg0, View view1, int pos, long id)
        {
    		SharedPreferences prefs = getSharedPreferences(ACCOUNT_PREFS_NAME, 0);
    		Editor edit = prefs.edit();
    		String select = (String) arg0.getItemAtPosition(pos);
    		if (select == "Default") {
    			imageFolder = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).getPath()+"/MyCameraApp/";
    			edit.putString("storeDir", "Default");
    		}
    		if (select == "External SD Card") {
    			imageFolder = "/mnt/sdcard/external_sd/MyCameraApp/";
    			edit.putString("storeDir", "External SD Card");
    		}
    		edit.commit();
        }

		@Override
		public void onNothingSelected(AdapterView<?> arg0) {
			// TODO Auto-generated method stub
			
		}
    };
    
    View.OnClickListener logout_handler = new View.OnClickListener() {
    	public void onClick(View v) {
    		logOut();
    	}
    };
    
    View.OnClickListener start_handler = new View.OnClickListener() {
        public void onClick(View v) {
        	mCam = camSurface.getCamera();
        	setContentView(R.layout.preview);
        	FrameLayout preview = (FrameLayout) findViewById(R.id.preview);
        	preview.addView(camSurface);
        	capture = (Button) findViewById(R.id.capture);
        	capture.setOnClickListener(capture_handler);
        	exit_cam = (Button) findViewById(R.id.exit);
        	exit_cam.setOnClickListener(exit_handler);
        	locationManager = (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);
            locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0, 0, locationListenerNET);
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, locationListenerGPS);
			tempDir = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
			tempDir = "/" + tempDir;
        }
    };
    
    View.OnClickListener main_exit_handler = new View.OnClickListener() {
		
		@Override
		public void onClick(View v) {
			finish();
		}
	};
	
	View.OnClickListener delete_handler = new View.OnClickListener() {
		
		@Override
		public void onClick(View v) {
			File folder = new File(imageFolder);
			File[] folderList = folder.listFiles();
    		for (int i = 0; i < folderList.length; i++) {
				DeleteRecursive(folderList[i]);
			}
    		showToast(imageFolder + " is now empty");
		}
	};
	
	View.OnClickListener upload_handler = new View.OnClickListener() {
		
		@Override
		public void onClick(View v) {
			//mDBApi.getSession().startAuthentication(RoadcamActivity.this);
			File folder = new File(imageFolder);
			File[] folderList = folder.listFiles();
			System.out.println(folder.getPath());
			db_upload(folder.getPath());
			/*for (int i = 0; i < folderList.length; i++) {
				if (folderList[i].isDirectory()) {
					System.out.println(folderList[i].getPath());
					db_upload(folderList[i].getPath());
				}
			}*/
			showToast(imageFolder + " has been uploaded");
			//db_upload("/mnt/sdcard/Pictures/MyCameraApp/20120716_125757/IMG_20120716_125803.jpg");
		}
	};
	
    View.OnClickListener exit_handler = new View.OnClickListener() {
		@Override
		public void onClick(View v) {
			if (timerRunning) {
				timerRunning = false;
				timerUpdateHandler.removeCallbacks(timerUpdateTask);
			}
			// TODO Auto-generated method stub
			onCreate(null);
		}
	};

    LocationListener locationListenerGPS = new LocationListener() {
    	public void onLocationChanged(Location location) {
    		gpsLocation = location;
    	}

		@Override
		public void onProviderDisabled(String provider) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void onProviderEnabled(String provider) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void onStatusChanged(String provider, int status, Bundle extras) {
			// TODO Auto-generated method stub
			
		}

    };

    LocationListener locationListenerNET = new LocationListener() {
    	public void onLocationChanged(Location location) {
    		netLocation = location;
    	}

		@Override
		public void onProviderDisabled(String provider) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void onProviderEnabled(String provider) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void onStatusChanged(String provider, int status, Bundle extras) {
			// TODO Auto-generated method stub
			
		}
    };

	public void gotLocation(Location location) {
	   	double ilong = location.getLongitude();
	   	double ilat = location.getLatitude();
	   	if (ilong < 0) {
	   		longD = "E";
	   	} else {
	   		longD = "W";
	   	}
	   	if (ilat < 0) {
	   		latD = "S";
	   	} else {
	   		latD = "N";
	   	}
	   	elatitude = convertDegrees(ilat);
	   	elongitude = convertDegrees(ilong);
	}
	
	public void showWarning() {
		AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
				context);
 
			// set title
			alertDialogBuilder.setTitle("Your location hasn't been found!");
 
			// set dialog message
			alertDialogBuilder
				.setMessage("Continue taking pictures?")
				.setCancelable(false)
				.setPositiveButton("Yes",new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog,int id) {
						
						tempDir = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
						tempDir = "/" + tempDir;
						timerRunning = true;
						Camera temp = camSurface.getCamera();
						capture.setText("Stop");
						temp.autoFocus(myAutoFocusCallback);
						dialog.cancel();
					}
				  })
				.setNegativeButton("No",new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog,int id) {
						dialog.cancel();
					}
				});
 
				// create alert dialog
				AlertDialog alertDialog = alertDialogBuilder.create();
 
				// show it
				alertDialog.show();
			}

	public String convertDegrees(double location) {
		if (location < 0) { location = location * -1; }
		int degrees = (int) location;
		location = 60 * (location - degrees);
		int minutes = (int) location;
		location = 60 * (location - minutes);
		int seconds = (int) location;
		return degrees + "/1," + minutes + "/1," + seconds + "/1";
	}
    
	private Runnable timerUpdateTask = new Runnable() {
		public void run() {
			if (currentTime < SECONDS_BETWEEN_PHOTOS) {
				currentTime++;
			} else {
				shootCamera();
				currentTime = 0;
			}
			timerUpdateHandler.postDelayed(timerUpdateTask, 1000);
		}
	};
	
    View.OnClickListener capture_handler = new View.OnClickListener() {
		@Override
		public void onClick(View v) {
			if (!timerRunning) {
				tempDir = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
				tempDir = "/" + tempDir;
				timerRunning = true;
				Camera temp = camSurface.getCamera();
				capture.setText("Stop");
				temp.autoFocus(myAutoFocusCallback);
				warned = false;
			}	
			else {
				timerRunning = false;
				timerUpdateHandler.removeCallbacks(timerUpdateTask);
				capture.setText("Start");
			}
		}
	};
	/*
	View.OnClickListener capture_handler = new View.OnClickListener() {
		
		@Override
		public void onClick(View v) {
			shootCamera();
		}
	};
	*/
	void shootCamera() {
		try {
		mCam = camSurface.getCamera();
		mCam.setErrorCallback(cb);
		mParams = mCam.getParameters();
		mCam.takePicture(null, null, jpegCallback);
		} catch (Error e) {
			System.out.println("restarting camera");
			mCam.release();
			shootCamera();
		}
	}
	
	Camera.ErrorCallback cb = new Camera.ErrorCallback() {
		@Override
		public void onError(int error, Camera camera) {
			// TODO Auto-generated method stub
			System.out.println("restarting camera");
			mCam.release();
			timerRunning = false;
		}
	};
	
	// This just gets called after the camera has finished autofocusing
	AutoFocusCallback myAutoFocusCallback = new AutoFocusCallback() {
		@Override
		public void onAutoFocus(boolean arg0, Camera arg1) {
			timerUpdateHandler.post(timerUpdateTask);
			//arg1.takePicture(null, null, jpegCallback); 
		}
	};
    
    PictureCallback jpegCallback = new PictureCallback() {
    	 @Override
    	 public void onPictureTaken(byte[] data, Camera camera) {
    		 System.out.println("" + data.length);
    		 File pictureFile = getOutputMediaFile();
    		 if (pictureFile == null){
    			 Log.d(TAG, "Error creating media file, check storage permissions: ");
    			 return;
    		 }
    		 try {
    			 FileOutputStream fos = new FileOutputStream(pictureFile);
    			 fos.write(data);
    			 fos.close();
    			 WriteExif(pictureFile.getPath(), mParams);
    		 } catch (FileNotFoundException e) {
    			 Log.d(TAG, "File not found: " + e.getMessage());
    		 } catch (IOException e) {
    			 Log.d(TAG, "Error accessing file: " + e.getMessage());
    		 }

         	
    	 }
    };
    
    private void writeImageData(String text) throws IOException {
    	String picDir = imageFolder + tempDir + tempDir + ".txt";
    	FileWriter f = new FileWriter(picDir, true);
    	System.out.println(picDir);
    	f.write(text);
    	f.close();
    }

    /** Create a File for saving an image or video */
    private static File getOutputMediaFile(){
        // To be safe, you should check that the SDCard is mounted
        // using Environment.getExternalStorageState() before doing this.
    	File mediaStorageDir = new File(imageFolder + tempDir);
        // This location works best if you want the created images to be shared
        // between applications and persist after your app has been uninstalled.

        // Create the storage directory if it does not exist
        if (! mediaStorageDir.exists()){
            if (! mediaStorageDir.mkdirs()){
                Log.d("MyCameraApp" + tempDir, "s");
                return null;
            }
        }

        // Create a media file name
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        File mediaFile;        
        mediaFile = new File(mediaStorageDir.getPath() + File.separator +
        		"IMG_" + timeStamp + ".jpg");
        return mediaFile;
    }
    
    protected void WriteExif(String fileName, Camera.Parameters tParams) throws IOException {
    	String locFlag = "loc:on"; 
    	if (gpsLocation == null) {
    		if (netLocation == null) {
    			longitude = "0";
    			latitude = "0";
    			elatitude = "0";
    			elongitude = "0";
    			latD = "N";
    			longD = "S";
    			locFlag = "loc:off";
    		}
    		else {
    			gotLocation(netLocation);
    			if (longitude == "0" && latitude == "0") {
        			showToast("Got Network location");
        		}
    			longitude = "" + netLocation.getLongitude();
    			latitude = "" + netLocation.getLatitude();
    		}
    	}
    	else {
    		gotLocation(gpsLocation);
    		if (longitude == "0" && latitude == "0") {
    			showToast("Got GPS location");
    		}
			longitude = "" + gpsLocation.getLongitude();
			latitude = "" + gpsLocation.getLatitude();
    	}
    	float[] results = {0, 0, 0};
    	mParams.getFocusDistances(results);
    	if (longitude == "0" && latitude == "0" && warned == false) {
    		timerRunning = false;
			timerUpdateHandler.removeCallbacks(timerUpdateTask);
			capture.setText("Start");
			warned = true;
    		showWarning();
    	}
    	writeImageData(fileName.substring(fileName.lastIndexOf("/")+1) + "||" + longitude + ", " + latitude + "||" + orientation[0] + "||" + results[0] + ", " + results[1] + ", " + results[2] + "||" + accelx[0] + ", " + accely[0] + ", " + accelz[0] + "||" + locFlag + "\n");
    	ExifInterface exifInterface = new ExifInterface(fileName);
    	exifInterface.setAttribute(exifInterface.TAG_GPS_LATITUDE, elatitude);
    	exifInterface.setAttribute(exifInterface.TAG_GPS_LATITUDE_REF, latD);
    	exifInterface.setAttribute(exifInterface.TAG_GPS_LONGITUDE, elongitude);
    	exifInterface.setAttribute(exifInterface.TAG_GPS_LATITUDE_REF, longD);
    	exifInterface.saveAttributes();
    	System.out.println("D = " + results[0] + ", " + results[1] + ", " + results[2]);
    }

	@Override
	public void onAccuracyChanged(Sensor arg0, int arg1) {
		
	}

	@Override
	public void onSensorChanged(SensorEvent event) {
		if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
			getAccelerometer(event);
		}
		else if(event.sensor.getType() == Sensor.TYPE_ORIENTATION) {
			getOrientation(event);
		}
	}
	
	private void getOrientation(SensorEvent event) {
		orientation = event.values;
		
	}
	
	private void getAccelerometer(SensorEvent event) {
		accelx[0] = accelx[1];
		accely[0] = accely[1];
		accelz[0] = accelz[1];
		accelx[1] = event.values[0];
		accely[1] = event.values[1];
		accelz[1] = event.values[2];
		lowPassFilter();
	}
	
	private void lowPassFilter() {
		;
	}
	 
	@Override
	protected void onResume() {
		super.onResume();
		session = mDBApi.getSession();
		sensorManager.registerListener(this,
				sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER),
				SensorManager.SENSOR_DELAY_NORMAL);
		if (mDBApi.getSession().authenticationSuccessful()) {
	        try {
	            // MANDATORY call to complete auth.
	            // Sets the access token on the session
	            mDBApi.getSession().finishAuthentication();

	            tokens = mDBApi.getSession().getAccessTokenPair();
	            storeKeys(tokens.key, tokens.secret);
	        } catch (IllegalStateException e) {
	            Log.i("DbAuthLog", "Error authenticating", e);
	        }
	    }
	}
	
	private void logOut() {
        // Remove credentials from the session
        mDBApi.getSession().unlink();

        // Clear our stored keys
        clearKeys();
        // Change UI state to display logged out version
    }
	
	private AndroidAuthSession buildSession() {
	        AppKeyPair appKeyPair = new AppKeyPair(APP_KEY, APP_SECRET);
	        AndroidAuthSession session;
	        String[] stored = getKeys();
	        if (stored != null) {
	            AccessTokenPair accessToken = new AccessTokenPair(stored[0], stored[1]);
	            session = new AndroidAuthSession(appKeyPair, ACCESS_TYPE, accessToken);
	        } else {
	            session = new AndroidAuthSession(appKeyPair, ACCESS_TYPE);
	        }

	        return session;
	    }

	private void showToast(String msg) {
        Toast error = Toast.makeText(context, msg, Toast.LENGTH_LONG);
        error.show();
    }
	
	@Override
	protected void onPause() {
		super.onPause();
		locationManager.removeUpdates(locationListenerGPS);
		locationManager.removeUpdates(locationListenerNET);
		sensorManager.unregisterListener(this);
	}
	
	@Override
	protected void onDestroy() {
		super.onDestroy();
		locationManager.removeUpdates(locationListenerGPS);
		locationManager.removeUpdates(locationListenerNET);
		sensorManager.unregisterListener(this);
	}
}