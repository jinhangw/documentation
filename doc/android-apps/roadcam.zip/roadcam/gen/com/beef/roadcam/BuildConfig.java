/** Automatically generated file. DO NOT MODIFY */
package com.beef.roadcam;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}