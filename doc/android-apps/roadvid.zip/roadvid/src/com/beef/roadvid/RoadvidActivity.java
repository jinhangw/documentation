package com.beef.roadvid;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.beef.roadvid.UploadPicture;
import com.dropbox.client2.DropboxAPI;
import com.dropbox.client2.android.AndroidAuthSession;
import com.dropbox.client2.session.AccessTokenPair;
import com.dropbox.client2.session.AppKeyPair;
import com.dropbox.client2.session.Session.AccessType;


import android.app.Activity;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.hardware.Camera;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.media.CamcorderProfile;
import android.media.MediaRecorder;
import android.media.MediaRecorder.OnInfoListener;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemSelectedListener;

public class RoadvidActivity extends Activity implements SensorEventListener {
	Button start, capture, exit_main, exit_cam, upload, delete, logout;
	TextView uploadStatus;
	
	Handler timerUpdateHandler;
	Handler uploadUpdateHandler;
	
	Context context;
	
    Camera mCamera;
    CameraPreview mPreview;
    private MediaRecorder mMediaRecorder;
    private boolean isRecording = false;
    
    final static private String ACCOUNT_PREFS_NAME = "prefs";
    final static private String ACCESS_KEY_NAME = "ACCESS_KEY";
    final static private String ACCESS_SECRET_NAME = "ACCESS_SECRET";
	final static private String APP_KEY = "o3bumzckzd7abst";
	final static private String APP_SECRET = "5pl94w5h50qc262";
	final static private AccessType ACCESS_TYPE = AccessType.APP_FOLDER;
	private DropboxAPI<AndroidAuthSession> mDBApi;
	AppKeyPair appKeys;
	AndroidAuthSession session;
	AccessTokenPair tokens;
	
	String[] errors = {"No files have been uploaded yet"};
	String uploadStatusHead = "Upload Status:\n";
	String uploadStatusMsg = "No files have been uploaded yet";
	
    LocationManager locationManager;
	Location gpsLocation;
	Location netLocation;
	String longitude, latitude;

	float[] orientation;
	float accel[] = {0, 0, 0};
	
	Spinner saveLocation;
	String saveLocations[];
	String imageFolder;
	static String startTime = "";
	
	static String tempdir;
	
	Boolean firstLogin = true;
	Boolean firstWarning = true;
	Boolean firstBluetooth = true;
	
	SensorManager sensorManager;
	
	ConnectThread bluetoothConnection;
	BluetoothAdapter mBluetoothAdapter;
	BluetoothDevice OBDII;
	
	int write_timer_delay = 50;
	
	int capRate = 10;
	/** Called when the activity is first created. */
	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        context = this;
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setContentView(R.layout.main);
        start = (Button) findViewById(R.id.start);
        start.setOnClickListener(start_handler);
        exit_main = (Button) findViewById(R.id.exit);
        exit_main.setOnClickListener(main_exit_handler);
        upload = (Button) findViewById(R.id.upload);
        upload.setOnClickListener(upload_handler);
        delete = (Button) findViewById(R.id.delete);
        delete.setOnClickListener(delete_handler);
        logout = (Button) findViewById(R.id.logout);
        logout.setOnClickListener(logout_handler);
        uploadStatus = (TextView) findViewById(R.id.uploadstatus);
        
        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
		sensorManager.registerListener(this,
				sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER),
				SensorManager.SENSOR_DELAY_NORMAL);
		sensorManager.registerListener(this,
				sensorManager.getDefaultSensor(Sensor.TYPE_ORIENTATION),
				sensorManager.SENSOR_DELAY_NORMAL);
        
        timerUpdateHandler = new Handler();
        uploadUpdateHandler = new Handler();
        
        SharedPreferences prefs = getSharedPreferences(ACCOUNT_PREFS_NAME, 0);
        if (prefs.getString("storeDir", "0") == "External SD Card") {
        	saveLocations = new String[] {"External SD Card", "Default"};
        	imageFolder = "/mnt/sdcard/external_sd/MyCameraApp/";
        }
        else {
        	saveLocations = new String[] {"Default", "External SD Card"};
            imageFolder = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).getPath()+"/MyCameraApp/";
        }
        
        errors[0] = prefs.getString("uploadStatus", "No files have been uploaded yet");
        
        locationManager = (LocationManager) this.getSystemService(Context.LOCATION_SERVICE);
        locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0, 0, locationListenerNET);
        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, locationListenerGPS);
        
        saveLocation = (Spinner) findViewById(R.id.saveSelect);
        ArrayAdapter locationAdapter = new ArrayAdapter(this, android.R.layout.simple_spinner_item, saveLocations);
        locationAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
    	saveLocation.setAdapter(locationAdapter);
		saveLocation.setOnItemSelectedListener(saveSelect);
		uploadUpdateHandler.post(uploadUpdateTask);
		
		session = buildSession();
		mDBApi = new DropboxAPI<AndroidAuthSession>(session);
		if (firstLogin) {
			mDBApi.getSession().startAuthentication(context);
			firstLogin = false;
		} /*
		mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
		if (mBluetoothAdapter == null) {
		    System.out.printlnln("no bluetooth\n");
		}
		if (firstBluetooth) {
			if (!mBluetoothAdapter.isEnabled()) {
				Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
		    	startActivityForResult(enableBtIntent, 1);
			}
			OBDII = null;
			for (BluetoothDevice B : mBluetoothAdapter.getBondedDevices()) {
				if (B.getName().equals("CBT.")) {
					OBDII = B;					
				}
			}
			if (OBDII != null) {
				bluetoothConnection = new ConnectThread(OBDII);
				//bluetoothConnection.run();
			}
		} */
    }
	
	void updateUploadStatus() {
		SharedPreferences prefs = getSharedPreferences(ACCOUNT_PREFS_NAME, 0);
		Editor edit = prefs.edit();
		edit.putString("uploadStatus", errors[0]);
		edit.commit();
		
		uploadStatusMsg = errors[0];
		uploadStatus.setText(uploadStatusHead + uploadStatusMsg);
		System.out.println(uploadStatusHead + uploadStatusMsg);
	}
	
    View.OnClickListener main_exit_handler = new View.OnClickListener() {
		
		@Override
		public void onClick(View v) {
			finish();
		}
	};
	
	View.OnClickListener delete_handler = new View.OnClickListener() {
		
		@Override
		public void onClick(View v) {
			File folder = new File(imageFolder);
			File[] folderList = folder.listFiles();
    		for (int i = 0; i < folderList.length; i++) {
				DeleteRecursive(folderList[i]);
			}
    		showToast(imageFolder + " is now empty");
		}
	};

    View.OnClickListener logout_handler = new View.OnClickListener() {
    	public void onClick(View v) {
    		logOut();
    	}
    };
	
	View.OnClickListener start_handler = new View.OnClickListener() {
		
		@Override
		public void onClick(View v) {
			System.out.println("Pressed Handler");

			setContentView(R.layout.preview);
			mCamera = getCameraInstance();
			mPreview = new CameraPreview(context, mCamera);
			FrameLayout preview = (FrameLayout) findViewById(R.id.camera_preview);
			preview.addView(mPreview);
			capture = (Button) findViewById(R.id.capture);
			capture.setOnClickListener(capture_handler);
			exit_cam = (Button) findViewById(R.id.exit);
			exit_cam.setOnClickListener(exit_handler);
			locationManager = (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);
			locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0, 0, locationListenerNET);
			locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, locationListenerGPS);
			firstWarning = true;	
		}
	};
	
	View.OnClickListener exit_handler = new View.OnClickListener() {
		
		@Override
		public void onClick(View v) {
			if (isRecording) {
				capture_handler.onClick(v);
			}
			mCamera.release();
			onCreate(null);
		}
	};
	
	View.OnClickListener capture_handler = new View.OnClickListener() {
		@Override
		public void onClick(View v) {
			if (isRecording) {
				System.out.println("ending recording");
				// stop recording and release camera
                mMediaRecorder.stop();  // stop the recording
                System.out.println("recording stopped");
                releaseMediaRecorder(); // release the MediaRecorder object
                mCamera.lock();         // take camera access back from MediaRecorder

          /*      try {
					//writeImageData("START: " + startTime + "\n" +"STOP: " + new SimpleDateFormat("yyyyMMdd_HHmmss_SSS").format(new Date()), 4);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} */
                // inform the user that recording has stopped
                capture.setText("Capture");
                isRecording = false;
                timerUpdateHandler.removeCallbacks(timerUpdateTask);
            } else {
            	if (gpsLocation == null && netLocation == null && firstWarning) {
            		showWarning(); 
            	} else {
            	
                // initialize video camera
            	tempdir = "/" + new SimpleDateFormat("yyyyMMdd_HHmmss_SSS").format(new Date());
                if (prepareVideoRecorder()) {
                	System.out.println("Prepared recorder");
                    // Camera is available and unlocked, MediaRecorder is prepared,
                    // now you can start recording                	
                    mMediaRecorder.start();
                    System.out.println("Started Recorder");
                    startTime = new SimpleDateFormat("yyyyMMdd_HHmmss_SSS").format(new Date()) + "";
                    // inform the user that recording has started
                    capture.setText("Stop");
                    isRecording = true;
                    timerUpdateHandler.post(timerUpdateTask);
                } else {
                    // prepare didn't work, release the camera
                    releaseMediaRecorder();
                    // inform user
                }
            	}
            }
		}
	};
	
	OnItemSelectedListener saveSelect = new OnItemSelectedListener() {
    	@Override
        public void onItemSelected(AdapterView<?> arg0, View view1, int pos, long id)
        {
    		SharedPreferences prefs = getSharedPreferences(ACCOUNT_PREFS_NAME, 0);
    		Editor edit = prefs.edit();
    		String select = (String) arg0.getItemAtPosition(pos);
    		if (select == "Default") {
    			imageFolder = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).getPath()+"/MyCameraApp/";
    			edit.putString("storeDir", "Default");
    		}
    		if (select == "External SD Card") {
    			imageFolder = "/mnt/sdcard/external_sd/MyCameraApp/";
    			edit.putString("storeDir", "External SD Card");
    		}
    		edit.commit();
        }

		@Override
		public void onNothingSelected(AdapterView<?> arg0) {
			// TODO Auto-generated method stub
			
		}
    };
	
    void DeleteRecursive(File fileOrDirectory) {
        if (fileOrDirectory.isDirectory())
            for (File child : fileOrDirectory.listFiles())
                DeleteRecursive(child);

        fileOrDirectory.delete();
    }
    
    public void db_upload(String path) {
    	// Uploading content.
    	File file = new File(path);
    	File[] fileList = file.listFiles();
    	UploadPicture upload = new UploadPicture(this, mDBApi, "", file, errors);
    	upload.execute();
    }
    
    private void getOrientation(SensorEvent event) {
		orientation = event.values;
		
	}
	
	private void getAccelerometer(SensorEvent event) {
		accel[0] = event.values[0];
		accel[1] = event.values[1];
		accel[2] = event.values[2];
	}
    
    @Override
	public void onSensorChanged(SensorEvent event) {
		if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
			getAccelerometer(event);
			/*try {
				if (isRecording) {
					//writeImageData(new SimpleDateFormat("yyyyMMdd_HHmmss_SSS").format(new Date()) + ": " + accel[0] + ", " + accel[1] + ", " + accel[2] + "\n", 1);
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}*/
		}
		else if(event.sensor.getType() == Sensor.TYPE_ORIENTATION) {
			getOrientation(event);
		}
	}
    
    @Override
	public void onAccuracyChanged(Sensor sensor, int accuracy) {
		// TODO Auto-generated method stub
		
	}
    
	LocationListener locationListenerGPS = new LocationListener() {
    	public void onLocationChanged(Location location) {
    		gpsLocation = location;
    	/*	try {
				//writeImageData(new SimpleDateFormat("yyyyMMdd_HHmmss_SSS").format(new Date()) + ": " + gpsLocation.getLongitude() + ", " + gpsLocation.getLatitude() + "\n", 2);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} */
    	}

		@Override
		public void onProviderDisabled(String provider) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void onProviderEnabled(String provider) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void onStatusChanged(String provider, int status, Bundle extras) {
			// TODO Auto-generated method stub
			
		}
    };

    LocationListener locationListenerNET = new LocationListener() {
    	public void onLocationChanged(Location location) {
    		netLocation = location;
    		/*try {
			//	writeImageData(new SimpleDateFormat("yyyyMMdd_HHmmss_SSS").format(new Date()) + ": " + netLocation.getLongitude() + ", " + netLocation.getLatitude() + "\n", 3);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} */
    	}

		@Override
		public void onProviderDisabled(String provider) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void onProviderEnabled(String provider) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void onStatusChanged(String provider, int status, Bundle extras) {
			// TODO Auto-generated method stub
			
		}
    };
    
    private Runnable uploadUpdateTask = new Runnable() {
    	public void run() {
    		System.out.println(errors[0]);
    		updateUploadStatus();
			uploadUpdateHandler.postDelayed(uploadUpdateTask, 1000);
    	}
    };
	
	private Runnable timerUpdateTask = new Runnable() {
		public void run() {
		/*	try {
				if (gpsLocation == null) {
		    		if (netLocation == null) {
		    			longitude = "0";
		    			latitude = "0";
		    		}
		    		else {
		    			longitude = "" + netLocation.getLongitude();
		    			latitude = "" + netLocation.getLatitude();
		    		}
		    	}
		    	else {
					longitude = "" + gpsLocation.getLongitude();
					latitude = "" + gpsLocation.getLatitude();
		    	}
			//	writeImageData(new SimpleDateFormat("yyyyMMdd_HHmmss_SSS").format(new Date()) + "||" + longitude + ", " + latitude + "||" + orientation[0] + "||" + "0 ,0 ,0 ||" + accel[0] + ", " + accel[1] + ", " + accel[2] + "\n", 0);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}*/
			timerUpdateHandler.postDelayed(timerUpdateTask, write_timer_delay);
		}
	};
	
	
	
	private void writeImageData(String text, int type) throws IOException {
		String picDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).getPath() + "/MyCameraApp" + tempdir + tempdir;
		if (type == 0) {
			picDir += "-all.txt";
		}
		else if(type == 1) {
			picDir += "-accel.txt";	
		}
		else if(type == 2) {
			picDir += "-gps.txt";	
		}
		else if(type == 3) {
			picDir += "-network.txt";	
		}
		else if(type == 4) {
			picDir += "-startstop.txt";		
		}
		else {
			return;
		}
    	FileWriter f = new FileWriter(picDir, true);
    	f.write(text);
    	f.close();
    }
	
    /** A safe way to get an instance of the Camera object. */
    public static Camera getCameraInstance() {
        Camera c = null;
        try {
            c = Camera.open(); // attempt to get a Camera instance
        }
        catch (Exception e)	{
        	System.out.println(e);
            // Camera is not available (in use or does not exist)
        }
        return c; // returns null if camera is unavailable
    }
    
    /** Prepare the Camera with video settings */
    private boolean prepareVideoRecorder(){

        mMediaRecorder = new MediaRecorder();
        
        // Step 1: Unlock and set camera to MediaRecorder
        mCamera.unlock();
        mMediaRecorder.setCamera(mCamera);
        
        mMediaRecorder.setMaxFileSize(50000000);
        mMediaRecorder.setOnInfoListener(new OnInfoListener() {
            @Override
            public void onInfo(MediaRecorder mr, int what, int extra) {                     
                if (what == MediaRecorder.MEDIA_RECORDER_INFO_MAX_FILESIZE_REACHED) {
                	if (isRecording) {
                		capture_handler.onClick(null);
                		capture_handler.onClick(null);
                	}
                	finish();

                }          
            }
        });
        
        // Step 2: Set sources
        mMediaRecorder.setVideoSource(MediaRecorder.VideoSource.CAMERA);

        // Step 3: Set a CamcorderProfile (requires API Level 8 or higher)
        mMediaRecorder.setProfile(CamcorderProfile.get(CamcorderProfile.QUALITY_TIME_LAPSE_HIGH));
        
        // Step 4: Set output file
        mMediaRecorder.setOutputFile(getOutputMediaFile().toString());

        // Step 5: Set the preview output
        mMediaRecorder.setPreviewDisplay(mPreview.getHolder().getSurface());
        mMediaRecorder.setCaptureRate(capRate);

        // Step 6: Prepare configured MediaRecorder
        try {
            mMediaRecorder.prepare();
        } catch (IllegalStateException e) {
            Log.d("Preparing video camera", "IllegalStateException preparing MediaRecorder: " + e.getMessage());
            releaseMediaRecorder();
            return false;
        } catch (IOException e) {
            Log.d("Preparing video camera", "IOException preparing MediaRecorder: " + e.getMessage());
            releaseMediaRecorder();
            return false;
        }
        return true;
    }
    
    /** Create a File for saving an image or video */
    private static File getOutputMediaFile() {
        // To be safe, you should check that the SDCard is mounted
        // using Environment.getExternalStorageState() before doing this.

        File mediaStorageDir = new File(Environment.getExternalStoragePublicDirectory(
                  Environment.DIRECTORY_PICTURES), "MyCameraApp" + tempdir);
        // This location works best if you want the created images to be shared
        // between applications and persist after your app has been uninstalled.

        // Create the storage directory if it does not exist
        if (! mediaStorageDir.exists()){
            if (! mediaStorageDir.mkdirs()){
                Log.d("MyCameraApp", "failed to create directory");
                return null;
            }
        }

        // Create a media file name
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss_SSS").format(new Date());
        File mediaFile;
        mediaFile = new File(mediaStorageDir.getPath() + File.separator +
        		"VID_" + tempdir.substring(1) + ".mp4");
        return mediaFile;
    }
    
    private String[] getKeys() {
        SharedPreferences prefs = getSharedPreferences(ACCOUNT_PREFS_NAME, 0);
        String key = prefs.getString(ACCESS_KEY_NAME, null);
        String secret = prefs.getString(ACCESS_SECRET_NAME, null);
        if (key != null && secret != null) {
        	String[] ret = new String[2];
        	ret[0] = key;
        	ret[1] = secret;
        	return ret;
        }
        return null;
    }
    
    private void storeKeys(String key, String secret) {
        // Save the access key for later
        SharedPreferences prefs = getSharedPreferences(ACCOUNT_PREFS_NAME, 0);
        Editor edit = prefs.edit();
        edit.putString(ACCESS_KEY_NAME, key);
        edit.putString(ACCESS_SECRET_NAME, secret);
        edit.commit();
    }

    private void clearKeys() {
        SharedPreferences prefs = getSharedPreferences(ACCOUNT_PREFS_NAME, 0);
        Editor edit = prefs.edit();
        edit.clear();
        edit.commit();
    }
    
    public void showWarning() {
		AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
				context);
			// set title
			alertDialogBuilder.setTitle("Your location hasn't been found!");
			firstWarning = false;
			// set dialog message
			alertDialogBuilder
				.setMessage("Continue capturing video?")
				.setCancelable(false)
				.setPositiveButton("Yes",new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog,int id) {
						tempdir = "/" + new SimpleDateFormat("yyyyMMdd_HHmmss_SSS").format(new Date());
		                // initialize video camera
		                if (prepareVideoRecorder()) {
		                    // Camera is available and unlocked, MediaRecorder is prepared,
		                    // now you can start recording
		                	System.out.println("warning time");
		                    mMediaRecorder.start();
		                    startTime = new SimpleDateFormat("yyyyMMdd_HHmmss_SSS").format(new Date()) + "";
		                    // inform the user that recording has started
		                    capture.setText("Stop");
		                    isRecording = true;
		                    timerUpdateHandler.post(timerUpdateTask);
		                } else {
		                    // prepare didn't work, release the camera
		                    releaseMediaRecorder();
		                }
					}
				  })
				.setNegativeButton("No",new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog,int id) {
						dialog.cancel();
					}
				});
 
				// create alert dialog
				AlertDialog alertDialog = alertDialogBuilder.create();
 
				// show it
				alertDialog.show();
			}
    
    View.OnClickListener upload_handler = new View.OnClickListener() {
		
		@Override
		public void onClick(View v) {
			//mDBApi.getSession().startAuthentication(RoadcamActivity.this);
			File folder = new File(imageFolder);
			File[] folderList = folder.listFiles();
			db_upload(folder.getPath());
			uploadUpdateHandler.post(uploadUpdateTask);
			showToast(imageFolder + " has been uploaded");
			//db_upload("/mnt/sdcard/Pictures/MyCameraApp/20120716_125757/IMG_20120716_125803.jpg");
		}
	};
    
    protected void onPause() {
        super.onPause();
        uploadUpdateHandler.removeCallbacks(uploadUpdateTask);
        //timerUpdateHandler.removeCallbacks(timerUpdateTask);
        locationManager.removeUpdates(locationListenerGPS);
		locationManager.removeUpdates(locationListenerNET);
		// sensorManager.unregisterListener(this);
        releaseMediaRecorder();       // if you are using MediaRecorder, release it first
        releaseCamera();              // release the camera immediately on pause event
    }

    @Override
	protected void onResume() {
		super.onResume();
		
		session = mDBApi.getSession();
		
		sensorManager.registerListener(this,
				sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER),
				SensorManager.SENSOR_DELAY_FASTEST);
		if (mDBApi.getSession().authenticationSuccessful()) {
	        try {
	            // MANDATORY call to complete auth.
	            // Sets the access token on the session
	            mDBApi.getSession().finishAuthentication();

	            tokens = mDBApi.getSession().getAccessTokenPair();
	            storeKeys(tokens.key, tokens.secret);
	        } catch (IllegalStateException e) {
	            Log.i("DbAuthLog", "Error authenticating", e);
	        }
	    }
	}
    
    private AndroidAuthSession buildSession() {
        AppKeyPair appKeyPair = new AppKeyPair(APP_KEY, APP_SECRET);
        AndroidAuthSession session;
        String[] stored = getKeys();
        if (stored != null) {
            AccessTokenPair accessToken = new AccessTokenPair(stored[0], stored[1]);
            session = new AndroidAuthSession(appKeyPair, ACCESS_TYPE, accessToken);
        } else {
            session = new AndroidAuthSession(appKeyPair, ACCESS_TYPE);
        }
        	
        return session;
    }
    
    private void logOut() {
        // Remove credentials from the session
        mDBApi.getSession().unlink();

        // Clear our stored keys
        clearKeys();
        // Change UI state to display logged out version
    }
    
    private void releaseMediaRecorder(){
        if (mMediaRecorder != null) {
            mMediaRecorder.reset();   // clear recorder configuration
            mMediaRecorder.release(); // release the recorder object
            mCamera.lock();           // lock camera for later use
            mMediaRecorder = null;
        }
    }

    private void releaseCamera(){
        if (mCamera != null){
            mCamera.release();        // release the camera for other applications
            mCamera = null;
        }
    }
    
    private void showToast(String msg) {
        Toast error = Toast.makeText(context, msg, Toast.LENGTH_LONG);
        error.show();
    }
}